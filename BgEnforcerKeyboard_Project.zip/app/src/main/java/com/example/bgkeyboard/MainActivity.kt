package com.example.bgkeyboard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        val infoText = TextView(this).apply {
            text = "BG Keyboard Enforcer\n\n" +
                   "1. Активируйте болгарскую клавиатуру в настройках или нажмите кнопку принудительной замены (требует WRITE_SECURE_SETTINGS).\n" +
                   "2. Русская раскладка в этой клавиатуре физически отсутствует — только болгарская (ЯВЕРТЪ / БДС)."
            textSize = 16f
            setPadding(0, 0, 0, 48)
        }

        val btnEnableSettings = Button(this).apply {
            text = "1. Включить в настройках Android"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val btnSelectIme = Button(this).apply {
            text = "2. Выбрать клавиатуру по умолчанию"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        val btnForceSwitch = Button(this).apply {
            text = "3. Принудительно удалить RU и включить BG (ADB)"
            setOnClickListener {
                forceBulgarianOnly()
            }
        }

        layout.addView(infoText)
        layout.addView(btnEnableSettings)
        layout.addView(btnSelectIme)
        layout.addView(btnForceSwitch)

        setContentView(layout)
    }

    private fun forceBulgarianOnly() {
        val myImeId = "${packageName}/.BgInputMethodService"
        try {
            // Оставляем включенной ТОЛЬКО нашу болгарскую клавиатуру (отключая Gboard/русские раскладки)
            Settings.Secure.putString(
                contentResolver,
                Settings.Secure.ENABLED_INPUT_METHODS,
                myImeId
            )
            // Назначаем нашу болгарскую клавиатуру активной по умолчанию
            Settings.Secure.putString(
                contentResolver,
                Settings.Secure.DEFAULT_INPUT_METHOD,
                myImeId
            )
            Toast.makeText(
                this,
                "Успех! Все русские раскладки отключены, активна только Болгарская!",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: SecurityException) {
            Toast.makeText(
                this,
                "Нет системных прав! Выполните через ADB:\nadb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
