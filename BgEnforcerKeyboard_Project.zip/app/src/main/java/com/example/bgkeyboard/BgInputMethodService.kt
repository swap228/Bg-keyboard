package com.example.bgkeyboard

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

class BgInputMethodService : InputMethodService() {

    private var isCaps = false
    private var isBdsLayout = false // false = Болгарская фонетическая (ЯВЕРТЪ), true = БДС (УЕИШЩ)
    private val keyButtons = mutableListOf<Button>()
    private lateinit var rootLayout: LinearLayout

    // Болгарская традиционная фонетическая раскладка (без Ы, Э, Ё — с Ъ, Ю, Ч, Ш, Щ)
    private val phoneticRows = listOf(
        listOf("ч", "ш", "щ", "ю", "ж", "ъ", "ѝ"),
        listOf("я", "в", "е", "р", "т", "ъ", "у", "и", "о", "п"),
        listOf("а", "с", "д", "ф", "г", "х", "й", "к", "л"),
        listOf("з", "ь", "ц", "ж", "б", "н", "м")
    )

    // Болгарская государственная стандартная раскладка (БДС)
    private val bdsRows = listOf(
        listOf("у", "е", "и", "ш", "щ", "к", "с", "д", "з", "ц"),
        listOf("ь", "я", "а", "о", "ж", "г", "т", "н", "в", "м", "ч"),
        listOf("ю", "й", "ъ", "э", "ф", "х", "п", "р", "л", "б")
    )

    override fun onCreateInputView(): View {
        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(8, 16, 8, 24)
        }
        buildKeyboard()
        return rootLayout
    }

    private fun buildKeyboard() {
        rootLayout.removeAllViews()
        keyButtons.clear()

        val activeRows = if (isBdsLayout) bdsRows else phoneticRows

        for (row in activeRows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            for (char in row) {
                val btn = createKeyButton(char) {
                    val out = if (isCaps) char.uppercase() else char
                    currentInputConnection?.commitText(out, 1)
                }
                keyButtons.add(btn)
                rowLayout.addView(btn)
            }
            rootLayout.addView(rowLayout)
        }

        // Нижний ряд: Shift, Переключатель Фонетика/БДС, Пробел, Backspace, Enter
        val bottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val shiftBtn = createSpecialButton("⇧", 1.2f) {
            isCaps = !isCaps
            updateLabels()
        }

        val modeLabel = if (isBdsLayout) "БДС" else "ФОН"
        val modeBtn = createSpecialButton(modeLabel, 1.3f) {
            isBdsLayout = !isBdsLayout
            buildKeyboard()
        }

        val spaceBtn = createSpecialButton("Български", 3.5f) {
            currentInputConnection?.commitText(" ", 1)
        }

        val delBtn = createSpecialButton("⌫", 1.3f) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }

        val enterBtn = createSpecialButton("↵", 1.3f) {
            currentInputConnection?.sendKeyEvent(
                KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)
            )
            currentInputConnection?.sendKeyEvent(
                KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)
            )
        }

        bottomRow.addView(shiftBtn)
        bottomRow.addView(modeBtn)
        bottomRow.addView(spaceBtn)
        bottomRow.addView(delBtn)
        bottomRow.addView(enterBtn)

        rootLayout.addView(bottomRow)
    }

    private fun createKeyButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = if (isCaps) label.uppercase() else label
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#333333"))
            setPadding(4, 16, 4, 16)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(3, 4, 3, 4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createSpecialButton(label: String, weight: Float, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#4A4A4A"))
            setPadding(4, 16, 4, 16)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply {
                setMargins(4, 6, 4, 6)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun updateLabels() {
        for (btn in keyButtons) {
            val current = btn.text.toString()
            btn.text = if (isCaps) current.uppercase() else current.lowercase()
        }
    }
}
